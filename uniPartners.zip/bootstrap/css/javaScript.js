var requestAnimationFrame = window.requestAnimationFrame || 
                            window.mozRequestAnimationFrame || 
                            window.webkitRequestAnimationFrame ||
                            window.msRequestAnimationFrame;
 
var transforms = ["transform", 
                  "msTransform", 
                  "webkitTransform", 
                  "mozTransform", 
                  "oTransform"];
                    
var transformProperty = getSupportedPropertyName(transforms);
 
var logos = [];
 
var browserWidth;
var browserHeight;
 
var numberOfLogos = 100;
 
var resetPosition = false;
 
function setup() {
    window.addEventListener("DOMContentLoaded", generateLogos, false);
    window.addEventListener("resize", setResetFlag, false);
}
setup();

function getSupportedPropertyName(properties) {
    for (var i = 0; i < properties.length; i++) {
        if (typeof document.body.style[properties[i]] != "undefined") {
            return properties[i];
        }
    }
    return null;
}
 
function Logo(element, speed, xPos, yPos) {
 
    this.element = element;
    this.speed = speed;
    this.xPos = xPos;
    this.yPos = yPos;

    this.counter = 0;
    this.sign = Math.random() < 0.5 ? 1 : -1;
     
    this.element.style.opacity = .1 + Math.random();
}
 
Logo.prototype.update = function () {
 
    this.counter += this.speed / 8000;
    this.xPos += this.sign * this.speed * Math.cos(this.counter) / 40;
    this.yPos += Math.sin(this.counter) / 40 + this.speed / 30;
     
    setTranslate3DTransform(this.element, Math.round(this.xPos), Math.round(this.yPos));
     
    if (this.yPos > browserHeight) {
        this.yPos = -50;
    }
}
 
function setTranslate3DTransform(element, xPosition, yPosition) {
    var val = "translate3d(" + xPosition + "px, " + yPosition + "px" + ", 0)";
    element.style[transformProperty] = val;
}
 
function generateLogos() {
     
    var originalLogo = document.querySelector(".logo");
     
    var logoContainer = originalLogo.parentNode;
     
    browserWidth = window.innerWidth;
    browserHeight = window.innerHeight;
             
    for (var i = 0; i < numberOfLogos; i++) {
     
        var logoClone = originalLogo.cloneNode(true);
        logoContainer.appendChild(logoClone);
     
        var initialXPos = getPosition(50, browserWidth);
        var initialYPos = getPosition(50, browserHeight);
        var speed = 5+Math.random()*40;
         
        var logoObject = new Logo(logoClone, 
                                            speed, 
                                            initialXPos, 
                                            initialYPos);
        logos.push(logoObject);
    }
     
    logoContainer.removeChild(originalLogo);
     
    moveLogos();
}
 
function moveLogos() {
    for (var i = 0; i < logos.length; i++) {
        var logo = logos[i];
        logo.update();
    }
     
    if (resetPosition) {
        browserWidth = window.innerWidth;
        browserHeight = window.innerHeight; 
         
        for (var i = 0; i < logos.length; i++) {
            var logo = logos[i];
             
            logo.xPos = getPosition(50, browserWidth);
            logo.yPos = getPosition(50, browserHeight);
        }
         
        resetPosition = false;
    }
     
    requestAnimationFrame(moveLogos);
}
 
function getPosition(offset, size) {
    return Math.round(-1*offset + Math.random() * (size+2*offset));
}
 
function setResetFlag(e) {
    resetPosition = true;
}